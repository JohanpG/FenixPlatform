// FenixPlatform project FenixPlatform.go
package FenixPlatform
