// FenixPlatform project doc.go

/*
FenixPlatform document
*/
package FenixPlatform
