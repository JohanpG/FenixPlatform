package domain

import "time"

type Transaction struct {
	ID                   int    `db:"TransactionID"`
	Code                 string `db:"TransactionCode"`
	TypeID               int    `db:"Type"`
	Type                 *Enumeration
	Date                 time.Time `db:"Date"`
	CurrencyFromID       *Currency
	CurrencyToID         *Currency
	TRMValue             float64 `db:"TRMValue"`
	PartnerID            int     `db:"PartnerID"`
	Partner              *Partner
	CurrencyFromQuantity float64 `db:"CurrencyFromQuantity"`
	CurrencyToQuantity   float64 `db:"CurrencyToQuantity"`
	PayType              *Enumeration
	IncoTerm             *Enumeration
	Casher               string `db:"Casher"`
	Notes                string `db:"Notes"`
}

type Enumeration struct {
	ID    int    `db:"EnumerationID"`
	Value string `db:"EnumerationValue"`
	Text  string `db:"EnumerationText"`
}

type Currency struct {
	ID          int    `db:"CurrencyID"`
	Code        string `db:"CurrencyCode"`
	Description string `db:"Description"`
}

type TRM struct {
	ID             int     `db:"TRMID"`
	CurrencyFromID int     `db:"CurrencyFromID"`
	CurrencyToID   int     `db:"CurrencyToID"`
	TRMValue       float64 `db:"TRMValue"`
}

type Partner struct {
	ID          int    `db:"PartnerID"`
	Code        string `db:"PartnerCode"`
	Name        string `db:"Name"`
	Address     string `db:"Address"`
	City        string `db:"City"`
	ZipCode     string `db:"ZipCode"`
	State       string `db:"State"`
	CountryCode string `db:"CountryCode"`
	Phone       string `db:"Phone"`
	Email       string `db:"Email"`
}

type RangeTransactionDates struct {
	StartDate string
	EndDate   string
	Hours     float64
}
